#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@2e9821423a237a1206e3c09020778faacfe430be"
#define SDL_REVISION_NUMBER 0
